import UIKit
var str = "T3: For Loop Demo!"
print(str)

for index in 1...5 {
  print("This is number \(index)")
}


for _ in 1...5 {
  print("Hello!")
}

let names = ["Joseph", "Cathy", "Winston"]
for name in names {
  print("Hello \(name)")
}


for letter in "ABCDEFG" {
  print("The letter is \(letter)")
}


for (index, letter) in "ABCDEFG".enumerated() {
  print("\(index): \(letter)")
}


let vehicles = ["unicycle" : 1, "bicycle" : 2, "tricycle" : 3, "quad bike" : 4]
for (vehicleName, wheelCount) in vehicles {
  print("A \(vehicleName) has \(wheelCount) wheels")
}

var numberOfLives = 3

while numberOfLives > 0 {
  //playMove()
  //updateLivesCount()
}

//var numberOfLives = 3

while numberOfLives > 0 {
  print("I still have \(numberOfLives) lives.")
}

//var numberOfLives = 3
var stillAlive = true

while stillAlive {
  print("I still have \(numberOfLives) lives.")
  numberOfLives -= 1
  if numberOfLives == 0 {
    stillAlive = false
  }
}

for counter in -10...10 {
  print(counter)
  if counter == 0 {
    break
  }
}


var sum = 0
for x in 1...10{
    sum+=x
}
print(sum)


var counter = 10
while counter > 0{
    print("Current value of counter is : \(counter)")
    //counter = counter - 1
    counter-=1
}

